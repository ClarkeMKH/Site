====================================================================
 M5Stack StickS3 - MicroPython + OTA Web Update Setup (Windows)
====================================================================

This package contains:
  - boot.py   -> connects to WiFi and starts a background web server
                 with a browser-based editor for main.py
  - main.py   -> your application code, wrapped in try/except so a
                 crash doesn't kill the OTA server
  - README.txt -> this file

--------------------------------------------------------------------
STAGE 1: Install Python
--------------------------------------------------------------------
1. Go to https://python.org/downloads and download the latest
   Python 3 installer.
2. Run it. On the first screen, TICK "Add python.exe to PATH"
   before clicking Install.
3. Open a fresh PowerShell window (Start menu -> type "PowerShell")
   and check it worked:

       python --version

   You should see something like "Python 3.12.x". If it's not
   recognized, open a new PowerShell window, or reinstall with the
   PATH box checked.

--------------------------------------------------------------------
STAGE 2: Install the flashing/upload tools
--------------------------------------------------------------------
In PowerShell:

       pip install esptool mpremote

Check they installed:

       esptool.py version
       mpremote --help

If "esptool.py" isn't recognized, try "python -m esptool version"
instead (same tool). Swap it in for every esptool command below if
needed.

--------------------------------------------------------------------
STAGE 3: Plug in the StickS3 and find its COM port
--------------------------------------------------------------------
1. Plug the StickS3 into your PC with a USB-C DATA cable (not a
   charge-only cable).
2. The ESP32-S3 has a native USB port, so Windows 10/11 should
   recognize it with no driver install needed.
3. Open Device Manager (Start -> "Device Manager") -> expand
   "Ports (COM & LPT)". You should see something like
   "USB Serial Device (COM5)". Note the COM number - you'll use it
   in every command below. Replace COM5 with your actual port in
   all the commands that follow.

If nothing shows up under Ports, try a different cable or USB port.

--------------------------------------------------------------------
STAGE 4: Download the MicroPython firmware
--------------------------------------------------------------------
1. Go to https://micropython.org/download/ESP32_GENERIC_S3/
2. Since the StickS3 has 8MB PSRAM, download a build with "SPIRAM"
   in the filename, e.g.:
       ESP32_GENERIC_S3-SPIRAM-20241129-v1.24.1.bin
3. Save it somewhere easy to find, e.g. C:\micropython\

--------------------------------------------------------------------
STAGE 5: Put the board in download mode and flash it
--------------------------------------------------------------------
Some boards enter download mode automatically. If flashing fails,
hold the side button down while plugging in the USB cable, keep
holding for ~2 seconds after it's plugged in, then release.

Open PowerShell in the folder with the .bin file:

       cd C:\micropython

Check esptool can see the chip:

       esptool.py --port COM5 flash_id

You should get chip info back ("Chip is ESP32-S3..."). If it times
out, redo the button-hold step and try again.

Erase the existing flash:

       esptool.py --chip esp32s3 --port COM5 erase_flash

Flash MicroPython (use your actual downloaded filename):

       esptool.py --chip esp32s3 --port COM5 --baud 460800 write_flash -z 0x0 ESP32_GENERIC_S3-SPIRAM-20241129-v1.24.1.bin

This takes ~10-20 seconds. When it finishes with "Hash of data
verified" / "Leaving...", it's flashed.

--------------------------------------------------------------------
STAGE 6: Confirm MicroPython is running
--------------------------------------------------------------------
       mpremote connect COM5

You should land on a ">>>" prompt. Try:

       print("hello")

It should echo back "hello". Press Ctrl+] to exit back to
PowerShell.

--------------------------------------------------------------------
STAGE 7: Set up your project folder
--------------------------------------------------------------------
Make a folder on your PC and copy boot.py and main.py (from this
zip) into it, e.g.:

       mkdir C:\sticks3-project
       (copy boot.py and main.py from this zip into that folder)
       cd C:\sticks3-project

--------------------------------------------------------------------
STAGE 8: Edit your WiFi credentials
--------------------------------------------------------------------
Open boot.py in Notepad or a code editor (VS Code, from
https://code.visualstudio.com, is a nicer free option) and change
these two lines near the top:

       WIFI_SSID = "YOUR_WIFI_SSID"
       WIFI_PASSWORD = "YOUR_WIFI_PASSWORD"

to your actual network name and password. Save the file.
Note: the ESP32-S3 WiFi radio is 2.4GHz only - it will not see a
5GHz-only network.

--------------------------------------------------------------------
STAGE 9: Upload the files to the device
--------------------------------------------------------------------
From inside C:\sticks3-project:

       mpremote connect COM5 fs cp boot.py :boot.py
       mpremote connect COM5 fs cp main.py :main.py

Double check they're there:

       mpremote connect COM5 fs ls

You should see boot.py and main.py listed.

--------------------------------------------------------------------
STAGE 10: Reboot and watch it come up
--------------------------------------------------------------------
       mpremote connect COM5 reset
       mpremote connect COM5

You should see something like:

       boot: connecting to WiFi 'YourNetwork' ...
       boot: WiFi connected, ip = 192.168.1.47
       boot: OTA server listening on port 80
       main.py: starting application
       main.py: tick 1
       main.py: tick 2
       ...

WRITE DOWN THAT IP ADDRESS - that's how you'll reach the device.
Press Ctrl+] to leave mpremote when done watching (this only
disconnects your terminal, it does not stop the board).

If WiFi fails to connect, double check the SSID/password in
boot.py, re-save, re-upload it (Stage 9), and reset again.

--------------------------------------------------------------------
STAGE 11: Update main.py from your browser
--------------------------------------------------------------------
Open this in a web browser, using your device's IP from Stage 10:

       http://192.168.1.47/

You'll see the current contents of main.py in an editable text box.
Make your changes and click "Save & Reboot" - the board will save
the new code and reboot into it. Reconnect with mpremote to watch
it come up if you want to confirm it worked.

Note: this is a plain text box, not a real code editor - no syntax
highlighting or error checking before it saves. If you introduce a
syntax error, it will still save fine but main.py will fail to run
on boot; the web page stays reachable so you can just fix it and
resubmit.

--------------------------------------------------------------------
STAGE 12 (optional): Update main.py from the command line instead
--------------------------------------------------------------------
Windows 10/11 PowerShell has curl built in. Edit main.py locally,
save it, then push it with (use curl.exe, not curl, in PowerShell):

       curl.exe -X POST --data-binary "@main.py" http://192.168.1.47/update

You should get back "main.py updated. Rebooting..." and the device
will reboot into the new code.

--------------------------------------------------------------------
TROUBLESHOOTING QUICK REFERENCE
--------------------------------------------------------------------
No COM port in Device Manager
    -> Try a different (data-capable) cable or USB port.

esptool.py times out / can't connect
    -> Hold the side button while plugging in USB, then retry.

mpremote hangs on connect
    -> Something else has the port open (close any other terminal
       or Thonny window). Ctrl+] first, then retry.

WiFi never connects
    -> Typo in SSID/password, or it's a 5GHz-only network.

curl / browser says connection refused
    -> Wrong IP, or your PC isn't on the same WiFi network as the
       device.

--------------------------------------------------------------------
SECURITY NOTE
--------------------------------------------------------------------
There is no authentication on the /update endpoint. Anyone on your
WiFi network can rewrite the device's code. This is fine for a
home/trusted LAN. If the device will ever be on a shared or
untrusted network, add a shared-secret check (e.g. a header or
query parameter compared against a hardcoded value) before writing
the uploaded file in boot.py.
