import time

# ---------------------------------------------------------------------------
# main.py - your application code
#
# This whole thing runs wrapped in try/except. If anything in here raises,
# we drop into the except block, print the error, and just idle - the OTA
# web server started in boot.py is on its own thread and keeps running,
# so you can still POST a fixed main.py to /update and it'll reboot into
# working code.
# ---------------------------------------------------------------------------
try:
    print("main.py: starting application")

    # === put your real application logic here ===
    counter = 0
    while True:
        counter += 1
        print("main.py: tick", counter)
        time.sleep(5)

except Exception as e:
    import sys
    print("main.py: crashed with exception:")
    sys.print_exception(e)
    print("main.py: OTA server (from boot.py) is still running - "
          "POST a fixed main.py to http://<device-ip>/update to recover.")

    # keep the process alive; the OTA server thread from boot.py
    # continues running in the background regardless of this loop
    while True:
        time.sleep(1)
