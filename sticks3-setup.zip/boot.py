import network
import socket
import _thread
import time
import machine

# ---------------------------------------------------------------------------
# CONFIG - edit these
# ---------------------------------------------------------------------------
WIFI_SSID = "YOUR_WIFI_SSID"
WIFI_PASSWORD = "YOUR_WIFI_PASSWORD"
OTA_PORT = 80

# ---------------------------------------------------------------------------
# WiFi
# ---------------------------------------------------------------------------
def connect_wifi(ssid, password, timeout_s=20):
    sta = network.WLAN(network.STA_IF)
    sta.active(True)
    if not sta.isconnected():
        print("boot: connecting to WiFi '%s' ..." % ssid)
        sta.connect(ssid, password)
        t = timeout_s
        while not sta.isconnected() and t > 0:
            time.sleep(1)
            t -= 1
    if sta.isconnected():
        print("boot: WiFi connected, ip =", sta.ifconfig()[0])
    else:
        print("boot: WiFi FAILED to connect")
    return sta


# ---------------------------------------------------------------------------
# Minimal OTA HTTP server
#
#   GET  /             -> HTML page with an editable textarea showing the
#                         current main.py, and a button that POSTs your
#                         edits back to /update
#   POST /update        -> body = new raw contents of main.py, written to
#                         /main.py, then the board reboots
#   POST /reset         -> just reboots
#
# You can still update from the command line too:
#   curl -X POST --data-binary @main.py http://<device-ip>/update
# ---------------------------------------------------------------------------
def _html_escape(text):
    return (text.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;"))


def _render_editor_page():
    try:
        with open("main.py", "r") as f:
            current_code = f.read()
    except OSError:
        current_code = ""

    escaped = _html_escape(current_code)

    return """<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>StickS3 - main.py editor</title>
<style>
  body {{ font-family: sans-serif; margin: 1.5em; background: #1e1e1e; color: #ddd; }}
  textarea {{
    width: 100%; height: 60vh; box-sizing: border-box;
    font-family: 'Consolas', monospace; font-size: 14px;
    background: #111; color: #eee; border: 1px solid #444;
    padding: 0.5em; white-space: pre; tab-size: 4;
  }}
  button {{
    margin-top: 0.75em; padding: 0.6em 1.4em; font-size: 15px;
    background: #2d7d46; color: white; border: none; border-radius: 4px;
    cursor: pointer;
  }}
  button:disabled {{ background: #555; }}
  #status {{ margin-left: 1em; font-family: monospace; }}
</style>
</head>
<body>
  <h2>main.py</h2>
  <textarea id="code" spellcheck="false">{code}</textarea>
  <br>
  <button id="btn" onclick="update()">Save &amp; Reboot</button>
  <span id="status"></span>

<script>
async function update() {{
  var btn = document.getElementById('btn');
  var status = document.getElementById('status');
  var code = document.getElementById('code').value;
  btn.disabled = true;
  status.textContent = 'uploading...';
  try {{
    const res = await fetch('/update', {{ method: 'POST', body: code }});
    const text = await res.text();
    status.textContent = res.ok ? (text + ' Reconnect shortly...') : ('Error: ' + text);
  }} catch (e) {{
    status.textContent = 'Request failed: ' + e;
  }}
  btn.disabled = false;
}}
</script>
</body>
</html>
""".format(code=escaped)


def _read_request(conn):
    conn.settimeout(10)
    data = b""
    while b"\r\n\r\n" not in data:
        chunk = conn.recv(1024)
        if not chunk:
            break
        data += chunk

    header_end = data.find(b"\r\n\r\n")
    header_bytes = data[:header_end]
    body = data[header_end + 4:]

    header_text = header_bytes.decode()
    lines = header_text.split("\r\n")
    method, path, _ = lines[0].split(" ")

    content_length = 0
    for line in lines[1:]:
        if line.lower().startswith("content-length"):
            content_length = int(line.split(":", 1)[1].strip())

    while len(body) < content_length:
        chunk = conn.recv(1024)
        if not chunk:
            break
        body += chunk

    return method, path, body


def _send(conn, status, content_type, body_bytes):
    if isinstance(body_bytes, str):
        body_bytes = body_bytes.encode()
    header = (
        "HTTP/1.1 {status}\r\n"
        "Content-Type: {ctype}\r\n"
        "Content-Length: {length}\r\n"
        "Connection: close\r\n\r\n"
    ).format(status=status, ctype=content_type, length=len(body_bytes))
    conn.send(header.encode() + body_bytes)


def _handle_client(conn):
    try:
        method, path, body = _read_request(conn)

        if method == "GET" and path == "/":
            _send(conn, "200 OK", "text/html", _render_editor_page())

        elif method == "POST" and path == "/update":
            if not body:
                _send(conn, "400 Bad Request", "text/plain", "empty body\n")
                return
            # write to a temp file first, then rename, so a failed/partial
            # upload never leaves main.py in a broken half-written state
            with open("main.py.tmp", "wb") as f:
                f.write(body)
            import os
            try:
                os.remove("main.py.bak")
            except OSError:
                pass
            try:
                os.rename("main.py", "main.py.bak")
            except OSError:
                pass  # no existing main.py yet
            os.rename("main.py.tmp", "main.py")

            _send(conn, "200 OK", "text/plain", "main.py updated. Rebooting...\n")
            time.sleep(0.5)
            machine.reset()

        elif method == "POST" and path == "/reset":
            _send(conn, "200 OK", "text/plain", "Rebooting...\n")
            time.sleep(0.5)
            machine.reset()

        else:
            _send(conn, "404 Not Found", "text/plain", "not found\n")

    except Exception as e:
        print("OTA server: error handling client:", e)
    finally:
        try:
            conn.close()
        except Exception:
            pass


def _serve_forever(port):
    addr = socket.getaddrinfo("0.0.0.0", port)[0][-1]
    s = socket.socket()
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind(addr)
    s.listen(5)
    print("boot: OTA server listening on port", port)
    while True:
        try:
            conn, remote_addr = s.accept()
            _handle_client(conn)
        except Exception as e:
            print("OTA server: loop error:", e)
            time.sleep(0.5)


def start_ota_server(port=OTA_PORT):
    _thread.start_new_thread(_serve_forever, (port,))


# ---------------------------------------------------------------------------
# boot.py entry point
# ---------------------------------------------------------------------------
connect_wifi(WIFI_SSID, WIFI_PASSWORD)
start_ota_server()

# NOTE: main.py is NOT imported here. MicroPython automatically runs
# main.py right after boot.py finishes - that's what gives main.py its
# own try/except and keeps this OTA server (already running on its own
# thread) alive even if main.py crashes.
